Key
ASCII value	GW productivity (litres/second)
VH	>20
H	5-20
M	1-5
LM	0.5-1
L	0.1-0.5
VL	<0.1