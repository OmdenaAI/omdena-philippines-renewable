Key
ASCII value	GW storage (water depth in mm)
0	0
L	<1000
LM	1000-10,000
M	10,000-25,000
H	25,000-50,000
VH	>50,000