Key
ASCII value	Depth to groundwater (mbgl)
VS	0-7
S	7-25
SM	25-50
M	50-100
D	100-250
VD	>250